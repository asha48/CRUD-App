package com.example.Management.dto;

import lombok.Data;

import java.util.Date;
@Data
public class TaskDto {
    private String title;
    private String description;


    private String dueDate;

    private Date updatedAt;
}
