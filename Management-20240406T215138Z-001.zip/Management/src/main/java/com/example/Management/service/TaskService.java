package com.example.Management.service;

import com.example.Management.dto.TaskDto;
import com.example.Management.model.Task;
import org.springframework.stereotype.Service;

import java.util.List;

public interface TaskService {
    public Task createTask(Task task);

    List<Task> getAllTasks();

    Task updateTask(Long id, TaskDto updatedTaskDto);
}
