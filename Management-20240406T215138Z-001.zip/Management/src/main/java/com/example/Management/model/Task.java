package com.example.Management.model;


import com.example.Management.dto.TaskDto;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.BeanUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Table(name = "task_table")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Getter
@Setter
public class Task {

    @Id
    @GeneratedValue
    private Long id;
    private String title;
    private String description;


    private String dueDate;

    private Date updatedAt;

    private Date createdAt =new Date();

    public void setUpdatedAt(String updatedAt) {
        if (updatedAt == null) {
            this.updatedAt = null;
            return;
        }
        SimpleDateFormat dateFmt = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//        log.info(last_updated);
        try {
            this.updatedAt = dateFmt.parse(updatedAt);
        } catch (ParseException e) {
//            log.error("setLast_updated: Exception ", e);
            throw new RuntimeException(e);
        }

    }

    public Task populateFrom(TaskDto dto) throws ParseException {
        BeanUtils.copyProperties(dto, this);
        this.updatedAt = new Date();

        return this;
    }
}