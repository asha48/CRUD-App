//package com.example.Management.config;
//
//import com.example.Management.utils.Encoder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
////import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity(securedEnabled = true, jsr250Enabled = true)
//public class SecurityConfig {
//    //public class SecurityConfig extends WebSecurityConfigurerAdapter {
////
////    @Override
////    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
////        auth
////                .inMemoryAuthentication()
////                .withUser("user").password("{noop}password").roles("USER");
////    }
////}
//    @Bean
//    public UserDetailsService userDetailsService(Encoder encoder) {
//        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
//        manager.createUser(User.withUsername("user")
//                .password(Encoder.calculateBase64("userPass"))
//                .roles("USER")
//                .build());
//        manager.createUser(User.withUsername("admin")
//                .password(Encoder.calculateBase64("adminPass"))
//                .roles("USER", "ADMIN")
//                .build());
//        return manager;
//    }
//
////    @Bean
////    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
////        http.csrf(AbstractHttpConfigurer::disable)
////                .authorizeHttpRequests(authorizationManagerRequestMatcherRegistry ->
////                        authorizationManagerRequestMatcherRegistry.requestMatchers(HttpMethod.DELETE).hasRole("ADMIN")
////                                .requestMatchers("/admin/**").hasAnyRole("ADMIN")
////                                .requestMatchers("/user/**").hasAnyRole("USER", "ADMIN")
////                                .requestMatchers("/login/**").permitAll()
////                                .anyRequest().authenticated())
////                .httpBasic(Customizer.withDefaults())
////                .sessionManagement(httpSecuritySessionManagementConfigurer -> httpSecuritySessionManagementConfigurer.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
////
////        return http.build();
////    }
//}
