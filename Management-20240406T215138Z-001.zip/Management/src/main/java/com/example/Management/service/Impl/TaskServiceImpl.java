package com.example.Management.service.Impl;

import com.example.Management.dto.TaskDto;
import com.example.Management.exception.AccessDeniedException;
import com.example.Management.exception.ResourceNotFoundException;
import com.example.Management.model.Task;
import com.example.Management.repository.TaskRepository;
import com.example.Management.service.TaskService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TaskServiceImpl implements TaskService {
    @Autowired
    private TaskRepository taskRepository;
    @Override
    public Task createTask(Task task) {
        return taskRepository.save(task);
    }

    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    @Override
    public Task updateTask(Long id, TaskDto updatedTaskDto) {
        Optional<Task> optionalTask = taskRepository.findById(id);
        System.out.println("existingTask"+optionalTask);
        if (optionalTask.isPresent()) {
            Task existingTask = optionalTask.get();
            // Update properties from updatedTaskDto to existingTask
            BeanUtils.copyProperties(updatedTaskDto, existingTask);
            // Save the updated task
            return taskRepository.save(existingTask);
        } else {
            throw new ResourceNotFoundException("Resource not found : task with given id does not exist");
        }
    }
}
