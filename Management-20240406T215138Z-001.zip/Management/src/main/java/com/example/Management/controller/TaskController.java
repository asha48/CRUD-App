package com.example.Management.controller;

import com.example.Management.dto.TaskDto;
import com.example.Management.model.Task;
import com.example.Management.service.TaskService;
import com.example.Management.utils.GenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/tasks")
@CrossOrigin("*")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private GenUtil genUtil;

    @PostMapping
    public ResponseEntity<?> createTask(@RequestBody TaskDto taskDto,@RequestHeader("username") String username,@RequestHeader("password") String password) {

        System.out.println("create task method is called");
        genUtil.authorization(username, password);
        Task newTask = new Task();
        try {
            newTask.populateFrom(taskDto);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        Task createdTask = taskService.createTask(newTask);
        return new ResponseEntity<>(createdTask, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Task>> getAllTasks(@RequestHeader("username") String username,@RequestHeader("password") String password) {
        System.out.println("getAllTAsk method is called");
        genUtil.authorization(username, password);
        List<Task> tasks = taskService.getAllTasks();
        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }

    @PutMapping("/{taskId}")
    public ResponseEntity<Task> updateTask(@PathVariable Long taskId, @RequestBody TaskDto updatedTaskDto,@RequestHeader("username") String username,@RequestHeader("password") String password) {
        System.out.println("updateTask method is called");
        genUtil.authorization(username, password);
        Task task = taskService.updateTask(taskId, updatedTaskDto);
        if (task != null) {
            return new ResponseEntity<>(task, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

