package com.example.Management.utils;

import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;

@Component
public class Encoder {
    public static String calculateBase64(String input) {
//        System.out.println("calculateBase64{} :input"+input);
        byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
        byte[] base64Encoded = Base64.getEncoder().encode(bytes);
//        System.out.println("calculateBase64{} : base64Encoded"+ Arrays.toString(base64Encoded));
        return new String(base64Encoded, StandardCharsets.UTF_8);
    }

}
