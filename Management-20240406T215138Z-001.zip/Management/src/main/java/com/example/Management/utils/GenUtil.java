package com.example.Management.utils;

import com.example.Management.exception.AccessDeniedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class GenUtil {
    @Value("${spring.username}")
    private String user;
    @Value("${spring.password}")
    private String pass;

    public boolean authorization(String username, String password) {

        String storedUsername = Encoder.calculateBase64(user);
        String storedPassword = Encoder.calculateBase64(pass);
        String user = Encoder.calculateBase64(username);
        String pass = Encoder.calculateBase64(password);

        if (!(storedUsername.equals(user) && storedPassword.equals(pass))) {
            throw new AccessDeniedException("Unauthorized: incorrect username and password");

        }
        return true;
    }
}
